#!/bin/bash
export SENDGRID_API_KEY="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"

